<?php
if (!defined('ABSPATH')) exit;

/**
 * Adds an admin page for Auto Post Fetcher.
 */
function auto_post_fetcher_menu() {
    add_menu_page('Auto Post Fetcher', 'Auto Post Fetcher', 'manage_options', 'auto-post-fetcher', 'auto_post_fetcher_page');
}
add_action('admin_menu', 'auto_post_fetcher_menu');

/**
 * Renders the admin page.
 */
function auto_post_fetcher_page() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['urls'])) {
        $urls = array_map('trim', explode("\n", sanitize_textarea_field($_POST['urls'])));
        fetch_and_create_posts($urls);
        echo '<div class="updated"><p>Posts created successfully!</p></div>';
    }
    echo '<form method="post"><textarea name="urls"></textarea><button type="submit">Fetch</button></form>';
}