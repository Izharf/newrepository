<?php
if (!defined('ABSPATH')) exit;

/**
 * Fetches content from URLs and creates WordPress posts.
 */
function fetch_and_create_posts($urls) {
    if (!is_array($urls)) return;

    foreach ($urls as $url) {
        $response = wp_remote_get($url);
        if (is_wp_error($response)) continue;
        
        $html = wp_remote_retrieve_body($response);
        if (empty($html)) continue;
        
        libxml_use_internal_errors(true);
        $doc = new DOMDocument('1.0', 'UTF-8'); // Force UTF-8 encoding
        $doc->loadHTML('<?xml encoding="utf-8" ?>' . mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8')); // Handle encoding issues
        libxml_clear_errors();
        
        $xpath = new DOMXPath($doc);
        
        // Extract title
        $title = '';
        $h1 = $xpath->query('//h1');
        if ($h1->length > 0) $title = trim($h1->item(0)->textContent);
        if (empty($title)) continue;
        
        // Extract first non-logo image and set as featured image
        $images = $xpath->query('//img');
        $featured_image_url = '';
        foreach ($images as $img) {
            if (stripos($img->getAttribute('alt'), 'logo') === false) {
                $featured_image_url = $img->getAttribute('src');
                $img->parentNode->removeChild($img); // Remove the image from content
                break;
            }
        }

        // Download and set featured image
        $featured_image_id = '';
        if (!empty($featured_image_url)) {
            $image_id = media_sideload_image($featured_image_url, 0, '', 'id');
            if (!is_wp_error($image_id)) $featured_image_id = $image_id;
        }

        // Extract content while preserving <b> and <strong>
        $content = '';
        $body = $xpath->query('//body//*[self::p or self::ul or self::br][not(ancestor::form)]');
        foreach ($body as $element) {
            $innerHTML = '';
            foreach ($element->childNodes as $child) {
                $innerHTML .= $doc->saveHTML($child);
            }

            // Clean the inner HTML of unwanted spaces and line breaks
            $trimmed_content = preg_replace('/\s+/', ' ', trim($innerHTML)); // Replaces multiple spaces with a single space
            $trimmed_content = preg_replace('/\s*<br\s*\/?>\s*/', '<br>', $trimmed_content); // Preserves <br> tags, but removes surrounding spaces

            // Replace non-breaking spaces with regular spaces
            $trimmed_content = str_replace('&nbsp;', ' ', $trimmed_content);

            // Avoid empty content
            if (!empty($trimmed_content)) {
                if ($element->nodeName === 'p') {
                    $content .= '<p>' . $trimmed_content . '</p>';
                } elseif ($element->nodeName === 'ul') {
                    $content .= '<ul>' . $trimmed_content . '</ul>';
                } elseif ($element->nodeName === 'br') {
                    // Preserve <br> tags
                    $content .= $trimmed_content;
                }
            }
        }

        // Create post
        $post_id = wp_insert_post([
            'post_title'   => $title,
            'post_content' => $content,
            'post_status'  => 'publish',
            'post_type'    => 'post'
        ]);

        if ($post_id && $featured_image_id) {
            set_post_thumbnail($post_id, $featured_image_id);
        }

        if ($post_id) {
            $post_slug = get_post_field('post_name', $post_id);
            $form_id = create_forminator_form($post_slug, $title, $html);
            if ($form_id) {
                $form_text = '<h2>Download ' . $title . ' Whitepaper</h2>';
                $content .= $form_text . '[formidable id="' . $form_id . '"]';
                wp_update_post(['ID' => $post_id, 'post_content' => $content]);
            }
        }
    }
}
?>
s