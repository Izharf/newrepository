<?php
if (!defined('ABSPATH')) exit;

/**
 * Creates a Formidable Form dynamically.
 */
function create_forminator_form($post_slug, $title, $html) {
    // Ensure Formidable Forms is active
    if (!class_exists('FrmForm') || !class_exists('FrmField')) {
        return '';
    }

    global $wpdb;

    // Check if the form already exists
    $existing_form_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}frm_forms WHERE form_key = %s",
        $post_slug
    ));

    if ($existing_form_id) {
        return $existing_form_id; // Return existing form ID if found
    }

    // Create a new Formidable Form
    $form_id = FrmForm::create([
        'form_key'    => sanitize_title($post_slug),
        'name'        => ucfirst($title),
        'status'      => 'published',
        'options'     => ['submit_value' => 'Submit'],
        'description' => '',
    ]);

    if (!$form_id) {
        return ''; // Exit if form creation fails
    }

    // Parse the HTML content
    libxml_use_internal_errors(true);
    $doc = new DOMDocument();
    $doc->loadHTML($html);
    libxml_clear_errors();

    $xpath = new DOMXPath($doc);

    // Find all form fields (input, textarea, select, and button)
    $fields = $xpath->query("//input | //textarea | //select | //button");

    foreach ($fields as $field) {
        // Determine field type based on node name and type attribute
        $nodeName = $field->nodeName;
        if ($nodeName === 'textarea') {
            $type = 'textarea';
        } elseif ($nodeName === 'select') {
            $type = 'select';
        } elseif ($nodeName === 'button') { 
            $type = 'button'; 
        } else {
            $type = $field->getAttribute('type') ?: 'text';
        }

        $name = $field->getAttribute('placeholder') ?: $field->getAttribute('name') ?: $field->getAttribute('id');

        // Skip hidden fields, but extract button text properly
        if (!$name || $type === 'hidden') {
            continue;
        }

        // Extract field label
        $label = '';

        if ($nodeName === 'button') {
            $label = trim($field->textContent); // Fix: Extract button text properly
        } else {
            $closest_label = $xpath->query(".//preceding-sibling::label", $field)->item(0);
            if ($closest_label) {
                $label = trim($closest_label->textContent);
            }

            if (!$label) {
                $labelQuery = $xpath->query("//label[@for='$name']");
                if ($labelQuery->length > 0) {
                    $label = trim($labelQuery->item(0)->textContent);
                }
            }

            if (!$label) {
                $label = ucfirst(str_replace(['_', '-'], ' ', $name)); // Fallback to name as label
            }
        }

        // Handle the privacy policy checkbox specifically
        if ($field->getAttribute('id') === 'check' && $type === 'checkbox') {
            $privacy_policy_html = '';
            $privacy_policy_span = $xpath->query(".//following-sibling::span", $field)->item(0);
            
            if ($privacy_policy_span) {
                foreach ($privacy_policy_span->childNodes as $child) {
                    $privacy_policy_html .= $privacy_policy_span->ownerDocument->saveHTML($child);
                }
                $privacy_policy_html = trim($privacy_policy_html);

                $allowed_html = [
                    'a' => [
                        'href' => true,
                        'style' => true,
                    ],
                    'span' => [
                        'style' => true,
                    ],
                ];
                $privacy_policy_html = wp_kses($privacy_policy_html, $allowed_html);
            }

            if ($privacy_policy_html) {
                $label = $privacy_policy_html;
            }
        }

        // Prepare field data
        $field_data = [
            'form_id'       => $form_id,
            'name'          => $label,
            'field_key'     => sanitize_title($name),
            'type'          => 'text', // Default type
            'required'      => $field->hasAttribute('required') ? 1 : 0,
            'description'   => '',
            'default_value' => $field->getAttribute('value') ?: '',
            'options'       => [],
            'field_options' => [],
        ];

        // Handle different field types
        switch ($type) {
            case 'email':
                $field_data['type'] = 'email';
                break;
            case 'textarea':
                $field_data['type'] = 'textarea';
                break;
            case 'checkbox':
                $field_data['type'] = 'checkbox';
                $field_data['name'] = ''; // Keep label empty
                $field_data['options'] = [$label]; // Use extracted label as checkbox option
                break;
            case 'radio':
                $field_data['type'] = 'radio';
                break;
            case 'select':
                $field_data['type'] = 'select';
                $options = [];
                foreach ($field->getElementsByTagName('option') as $option) {
                    $option_text = trim($option->textContent); // Fetch text inside <option> tag
                    $options[] = $option_text; // Use text instead of value
                }
                $field_data['options'] = $options;
                break;
            case 'button':
                $field_data['type'] = 'button';
                $field_data['name'] = $label; // Fix: Correctly extract button text
                break;
            default:
                $field_data['type'] = 'text';
                break;
        }

        // Create the field in Formidable Forms, but skip buttons
        if ($type !== 'button') {
            FrmField::create($field_data);
        }
    }

    // Add reCAPTCHA field above the submit button
    $recaptcha_field_data = [
        'form_id'       => $form_id,
        'name'          => 'reCAPTCHA',
        'field_key'     => 'recaptcha',
        'type'          => 'captcha',
        'required'      => 1,
        'description'   => '',
        'options'       => [],
        'field_options' => ['use_recaptcha' => 1],
    ];
    FrmField::create($recaptcha_field_data);

    return $form_id; // Return the created form ID
}
?>
