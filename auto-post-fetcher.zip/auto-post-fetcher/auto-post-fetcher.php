<?php
/*
Plugin Name: Auto Post Fetcher
Description: Fetches content from URLs and creates WordPress posts with dynamically generated Forminator Forms.
Version: 2.0
Author: Creatives
*/

if (!defined('ABSPATH')) exit;

// Load required files
require_once plugin_dir_path(__FILE__) . 'includes/form-creator.php';
require_once plugin_dir_path(__FILE__) . 'includes/post-fetcher.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin-page.php';

// Load WordPress media functions
require_once(ABSPATH . 'wp-admin/includes/media.php');
require_once(ABSPATH . 'wp-admin/includes/file.php');
require_once(ABSPATH . 'wp-admin/includes/image.php');





function my_plugin_enqueue_styles() {
    wp_enqueue_style(
        'my-plugin-styles', // Handle
        plugin_dir_url(__FILE__) . 'assets/css/style.css', // File path
        array(), // Dependencies (empty if none)
        '1.0' // Version
    );
}
add_action('wp_enqueue_scripts', 'my_plugin_enqueue_styles');